// Supabase setup: replace both placeholders with your own project values.
// Never put a Supabase service_role key in browser code.
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY";

const configured = SUPABASE_URL.startsWith("https://") &&
  !SUPABASE_URL.includes("YOUR_") && !SUPABASE_ANON_KEY.includes("YOUR_");
const client = configured && window.supabase
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

const $ = (id) => document.getElementById(id);
$("year").textContent = new Date().getFullYear();
if (configured) $("config-warning").hidden = true;

function authMessage(message, error = false) {
  $("auth-message").textContent = message;
  $("auth-message").style.color = error ? "#b42318" : "#247448";
}
function noteMessage(message, error = false) {
  $("note-message").textContent = message;
  $("note-message").style.color = error ? "#b42318" : "#247448";
}
function showPrivate(user) {
  $("auth-area").hidden = !!user;
  $("notes-area").hidden = !user;
  if (user) {
    $("user-label").textContent = `লগইন করা আছে: ${user.email}`;
    loadNotes();
  }
}
async function loadNotes() {
  if (!client) return;
  const { data, error } = await client.from("private_notes")
    .select("id,title,body,created_at").order("created_at", { ascending: false });
  if (error) { noteMessage("নোট লোড করা যায়নি: " + error.message, true); return; }
  const list = $("notes-list");
  list.replaceChildren();
  if (!data.length) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = "এখনও কোনো নোট নেই। উপরে প্রথম নোটটি লেখো।";
    list.append(empty);
    return;
  }
  data.forEach((item) => {
    const card = document.createElement("article");
    card.className = "note";
    const title = document.createElement("h4");
    title.textContent = item.title;
    const body = document.createElement("p");
    body.textContent = item.body;
    const date = document.createElement("small");
    date.textContent = new Date(item.created_at).toLocaleString("bn-BD");
    const remove = document.createElement("button");
    remove.className = "btn ghost small";
    remove.textContent = "মুছে ফেলো";
    remove.style.marginTop = "10px";
    remove.addEventListener("click", () => deleteNote(item.id));
    card.append(title, body, date, document.createElement("br"), remove);
    list.append(card);
  });
}
async function deleteNote(id) {
  if (!confirm("এই নোটটি মুছে ফেলতে চাও?")) return;
  const { error } = await client.from("private_notes").delete().eq("id", id);
  if (error) noteMessage("মুছতে সমস্যা হয়েছে: " + error.message, true);
  else { noteMessage("নোট মুছে ফেলা হয়েছে।"); loadNotes(); }
}

$("login-btn").addEventListener("click", async () => {
  if (!client) return authMessage("আগে app.js-এ Supabase সেটআপ সম্পন্ন করো।", true);
  const email = $("email").value.trim(), password = $("password").value;
  if (!email || !password) return authMessage("ইমেইল ও পাসওয়ার্ড লিখো।", true);
  const { error } = await client.auth.signInWithPassword({ email, password });
  if (error) authMessage(error.message, true);
});
$("signup-btn").addEventListener("click", async () => {
  if (!client) return authMessage("আগে app.js-এ Supabase সেটআপ সম্পন্ন করো।", true);
  const email = $("email").value.trim(), password = $("password").value;
  if (!email || password.length < 8) return authMessage("ইমেইল দাও এবং অন্তত ৮ অক্ষরের পাসওয়ার্ড ব্যবহার করো।", true);
  const { data, error } = await client.auth.signUp({ email, password });
  if (error) authMessage(error.message, true);
  else if (!data.session) authMessage("অ্যাকাউন্ট তৈরি হয়েছে। ইমেইল যাচাই করে তারপর লগইন করো।");
});
$("logout-btn").addEventListener("click", async () => {
  const { error } = await client.auth.signOut();
  if (error) noteMessage(error.message, true);
});
$("save-note-btn").addEventListener("click", async () => {
  const title = $("note-title").value.trim(), body = $("note-body").value.trim();
  if (!title || !body) return noteMessage("শিরোনাম ও নোট দুটোই লিখো।", true);
  const { data: { user } } = await client.auth.getUser();
  if (!user) return noteMessage("আবার লগইন করো।", true);
  const { error } = await client.from("private_notes").insert({ user_id: user.id, title, body });
  if (error) noteMessage("সংরক্ষণ হয়নি: " + error.message, true);
  else {
    $("note-title").value = ""; $("note-body").value = "";
    noteMessage("নোট নিরাপদভাবে সংরক্ষণের অনুরোধ সফল হয়েছে।");
    loadNotes();
  }
});

if (client) {
  client.auth.getSession().then(({ data }) => showPrivate(data.session?.user ?? null));
  client.auth.onAuthStateChange((_event, session) => showPrivate(session?.user ?? null));
} else {
  showPrivate(null);
}
